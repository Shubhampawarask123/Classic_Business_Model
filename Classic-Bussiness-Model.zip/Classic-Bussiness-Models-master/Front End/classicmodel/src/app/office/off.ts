export class Off{
    
    officeCode: number;
    city: string;
    phone:number;
    addressLine1:string;
    addressLine2: string;
    state: string;
    country: string;
    postalCode:number;
    territory:string;


constructor(){
    this.officeCode = 0;
    this.city="";
    this.phone=0;
    this.addressLine1 = "";
    this.addressLine2 = "";
    this.state = "";
    this.country = "";
    this.postalCode=0;
    this.territory="";


}

}