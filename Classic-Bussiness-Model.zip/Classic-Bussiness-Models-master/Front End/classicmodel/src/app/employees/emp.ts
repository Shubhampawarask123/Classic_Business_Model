export class Emp {
    employeeNumber: number;
    lastName: string;
    firstName: string;
    extension: string;
    email: string;
    officeCode: number;
    reportsTo: number;
    jobTitle: string;


    constructor() {
        this.employeeNumber =0 ;
        this.lastName = "";
        this.firstName = "";
        this.extension = "";
        this.email = "";
        this.officeCode = 0;
        this.reportsTo = 0;
        this.jobTitle = "";
        


    }

}