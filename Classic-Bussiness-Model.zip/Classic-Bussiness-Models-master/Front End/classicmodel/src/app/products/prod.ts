export class Prod{

    productCode:string;

    productName:string;

    productLine:string ;

    productScale:string;

    productVendor:string;

    productDescription:string;

    quantityInStock:number;

    buyPrice:number;

    msrp:number;

    //getCurrentData:any;




    constructor(){

        this.productCode = "";

        this.productName="";

        this.productLine="";

        this.productScale = "";

        this.productVendor = "";

        this.productDescription = "";

        this.quantityInStock = 0;

        this.buyPrice=0;

        this.msrp=0;




    }




}