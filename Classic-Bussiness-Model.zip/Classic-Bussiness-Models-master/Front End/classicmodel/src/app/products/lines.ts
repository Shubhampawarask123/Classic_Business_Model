export class Lines {
    productLine: string;
    textDescription: string;
    htmlDescription: string;
    image: string;

    constructor() {
        this.productLine = "";
        this.textDescription = "";
        this.htmlDescription = "";
        this.image = "";
    }
}