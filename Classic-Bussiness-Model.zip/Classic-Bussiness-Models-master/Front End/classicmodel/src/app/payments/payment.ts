export class Pay {

    customerNumber: number;
    checkNumber: string;
    paymentDate: string;
    amount: number

    constructor() {
        this.customerNumber = 0;
        this.checkNumber = "";
        this.paymentDate = "";
        this.amount = 0;

    }
}
