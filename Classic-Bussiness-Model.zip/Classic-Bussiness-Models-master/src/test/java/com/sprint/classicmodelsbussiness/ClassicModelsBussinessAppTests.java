package com.sprint.classicmodelsbussiness;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassicModelsBussinessAppTests {

	@Test
	void contextLoads() {
	}

}
