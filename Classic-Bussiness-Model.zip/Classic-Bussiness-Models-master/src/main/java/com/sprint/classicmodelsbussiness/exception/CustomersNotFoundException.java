package com.sprint.classicmodelsbussiness.exception;

public class CustomersNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 6132697282732348202L;

	public CustomersNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomersNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
