package com.sprint.classicmodelsbussiness.exception;

public class PaymentsNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PaymentsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PaymentsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
