package com.sprint.classicmodelsbussiness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassicModelsBussinessApp {

	public static void main(String[] args) {
		SpringApplication.run(ClassicModelsBussinessApp.class, args);
	}

}
